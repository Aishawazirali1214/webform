import React, { useState, useEffect } from "react";
import "./App.css";

// Mock API functions
const fetchAvailableTimes = async (date) => {
  // In a real app, this would call your actual API
  console.log("Fetching times for:", date);

  // Mock response - returns different times based on day of week
  const day = new Date(date).getDay();
  const allTimes = ["17:00", "18:00", "19:00", "20:00", "21:00"];

  // Fewer times on Sundays
  if (day === 0) return allTimes.slice(0, 3);
  return allTimes;
};

const submitBooking = async (bookingData) => {
  // In a real app, this would call your actual API
  console.log("Submitting booking:", bookingData);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true });
    }, 1000); // Simulate network delay
  });
};

const App = () => {
  const [step, setStep] = useState("form"); // 'form' or 'confirmation'
  const [availableTimes, setAvailableTimes] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const [formData, setFormData] = useState({
    date: "",
    time: "",
    guests: 2,
    occasion: "",
    name: "",
    email: "",
    phone: "",
  });

  // Fetch available times when date changes
  useEffect(() => {
    if (formData.date) {
      setIsLoading(true);
      fetchAvailableTimes(formData.date)
        .then((times) => {
          setAvailableTimes(times);
          setIsLoading(false);
        })
        .catch((err) => {
          setError("Failed to load available times");
          setIsLoading(false);
        });
    }
  }, [formData.date]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      await submitBooking(formData);
      setStep("confirmation");
    } catch (err) {
      setError("Failed to submit booking. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (step === "confirmation") {
    return (
      <div className="container">
        <h1>Booking Confirmed!</h1>
        <p>Thank you for your reservation, {formData.name}!</p>
        <div className="confirmation-details">
          <p>
            <strong>Date:</strong> {formData.date}
          </p>
          <p>
            <strong>Time:</strong> {formData.time}
          </p>
          <p>
            <strong>Guests:</strong> {formData.guests}
          </p>
          {formData.occasion && (
            <p>
              <strong>Occasion:</strong> {formData.occasion}
            </p>
          )}
        </div>
        <button
          onClick={() => {
            setStep("form");
            setFormData({
              date: "",
              time: "",
              guests: 2,
              occasion: "",
              name: "",
              email: "",
              phone: "",
            });
          }}
          className="button"
        >
          Make Another Reservation
        </button>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Little Lemon Restaurant</h1>
      <h2>Reserve a Table</h2>

      {error && <div className="error">{error}</div>}

      <form onSubmit={handleSubmit} className="booking-form">
        <div className="form-group">
          <label htmlFor="name">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="phone">Phone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="date">Date</label>
          <input
            type="date"
            id="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            min={new Date().toISOString().split("T")[0]}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="time">Time</label>
          <select
            id="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            disabled={!formData.date || isLoading}
            required
          >
            <option value="">Select a time</option>
            {availableTimes.map((time) => (
              <option key={time} value={time}>
                {time}
              </option>
            ))}
          </select>
          {isLoading && formData.date && (
            <div className="loading">Loading times...</div>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="guests">Number of Guests</label>
          <input
            type="number"
            id="guests"
            name="guests"
            min="1"
            max="10"
            value={formData.guests}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="occasion">Occasion (optional)</label>
          <select
            id="occasion"
            name="occasion"
            value={formData.occasion}
            onChange={handleChange}
          >
            <option value="">None</option>
            <option value="birthday">Birthday</option>
            <option value="anniversary">Anniversary</option>
            <option value="business">Business</option>
          </select>
        </div>

        <button type="submit" className="button" disabled={isLoading}>
          {isLoading ? "Submitting..." : "Reserve Table"}
        </button>
      </form>
    </div>
  );
};

export default App;
